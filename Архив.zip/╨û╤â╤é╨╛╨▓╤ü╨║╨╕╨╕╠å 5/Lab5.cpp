﻿#include "Header.h"

int main()
{
	// 1, 2, 7, 13, 14, 17, 20, 21
	EnterPoint();

	cout << "\nProgram end successfully\n";
}
