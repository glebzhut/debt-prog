﻿#include "MainHeader.h"


int main()
{
	EnterPoint();

	return 0;
}