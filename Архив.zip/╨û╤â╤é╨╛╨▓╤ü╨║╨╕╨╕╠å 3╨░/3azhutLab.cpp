﻿#include "Header.h"

int main() 
{
	srand((unsigned)time(0));

	CallWithoutBack(StartMenu, "Programm successfuly ends");
}